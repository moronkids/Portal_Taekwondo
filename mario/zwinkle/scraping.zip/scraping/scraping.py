# import urllib
import urllib.request

f= urllib.request.urlopen("http://127.0.0.1:8000/blog/krida/create-peserta-ujian/")
# f = urllib.urlopen("http://127.0.0.1:8000/blog/krida/create-peserta-ujian/")
s = f.read()
f.close()

from BeautifulSoup import BeautifulStoneSoup
soup = BeautifulStoneSoup(s)

inputTag = soup.findAll(attrs={"name" : "stainfo"})

output = inputTag[0]['value']

print (str(output))